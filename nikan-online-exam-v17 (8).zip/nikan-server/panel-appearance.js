/* Mother-panel presentation preferences. No school records or credentials are read or written. */
(function(){
 'use strict';
 const key='nikan_mother_appearance_v1';
 const defaults={font:'Vazirmatn',size:'1',color:'#101e46'};
 const options={font:['Vazirmatn','Tahoma','Arial'],size:['0.9','1','1.12','1.25'],color:['#101e46','#167a74','#59417d']};
 function clean(value){const result={};for(const field of Object.keys(defaults))result[field]=value&&options[field].includes(value[field])?value[field]:defaults[field];return result;}
 let current;try{current=clean(JSON.parse(localStorage.getItem(key)||'null'));}catch{current=clean(null);}
 function apply(){const s=document.documentElement.style;s.setProperty('--panel-font',current.font);s.setProperty('--panel-scale',current.size);s.setProperty('--panel-primary',current.color);}
 apply();
 let dialog,previousFocus;
 function close(){dialog.close();if(previousFocus)previousFocus.focus();}
 window.openMotherAppearance=function(){
  previousFocus=document.activeElement;
  if(!dialog){
   dialog=document.createElement('dialog');dialog.className='panel-appearance';dialog.setAttribute('aria-labelledby','mother-appearance-title');
   dialog.innerHTML='<h2 id="mother-appearance-title">ظاهر پنل مادر</h2><p>رنگ و نوشته‌ها را برای همین مرورگر تنظیم کنید.</p><label for="mother-appearance-color">رنگ اصلی (حالت روشن)</label><select id="mother-appearance-color"><option value="#101e46">سرمه‌ای نیکان</option><option value="#167a74">سبز آبی</option><option value="#59417d">بنفش</option></select><label for="mother-appearance-font">فونت</label><select id="mother-appearance-font"><option value="Vazirmatn">وزیرمتن</option><option value="Tahoma">تاهوما</option><option value="Arial">آریال</option></select><label for="mother-appearance-size">اندازه نوشته‌ها</label><select id="mother-appearance-size"><option value="0.9">کوچک</option><option value="1">متوسط</option><option value="1.12">بزرگ</option><option value="1.25">خیلی بزرگ</option></select><p id="mother-appearance-status" role="status" aria-live="polite"></p><div class="panel-dialog-actions"><button type="button" class="btn btn-outline" data-appearance-default>پیش‌فرض نیکان</button><button type="button" class="btn btn-primary" data-appearance-close>بستن</button></div>';
   document.body.appendChild(dialog);
   function update(){apply();try{localStorage.setItem(key,JSON.stringify(current));dialog.querySelector('[role=status]').textContent='ظاهر ذخیره شد.';}catch{dialog.querySelector('[role=status]').textContent='ظاهر اعمال شد؛ ذخیره در این مرورگر در دسترس نیست.';}}
   for(const field of Object.keys(defaults))dialog.querySelector('#mother-appearance-'+field).onchange=function(){current=clean({...current,[field]:this.value});update();};
   dialog.querySelector('[data-appearance-default]').onclick=function(){current=clean(null);for(const field of Object.keys(defaults))dialog.querySelector('#mother-appearance-'+field).value=current[field];update();};
   dialog.querySelector('[data-appearance-close]').onclick=close;
  }
  for(const field of Object.keys(defaults))dialog.querySelector('#mother-appearance-'+field).value=current[field];
  if(!dialog.open)dialog.showModal();
 };
})();
