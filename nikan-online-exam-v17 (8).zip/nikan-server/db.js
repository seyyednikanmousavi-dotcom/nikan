/**
 * لایه دیتابیس — سازگار با الگوی D1 (prepare/bind/first/all/run)
 * روی SQLite با better-sqlite3
 * نسخه پایدار برای PaaS ایرانی (Volume + DATA_DIR)
 */
const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const dataDir = process.env.DATA_DIR || path.join(__dirname, 'data');
try {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true, mode: 0o700 });
  }
} catch (e) {
  console.error('Cannot create dataDir:', dataDir, e.message);
}

const dbPath = process.env.DB_PATH || path.join(dataDir, 'nikan.sqlite');
console.log('=== DB PATH ===', dbPath);
console.log('=== DATA_DIR ===', process.env.DATA_DIR || '(not set)');
console.log('=== dataDir exists ===', fs.existsSync(dataDir));

let sqlite;
try {
  // Create private before SQLite opens it; tighten existing files without changing contents.
  try { const fd=fs.openSync(dbPath,'wx',0o600);fs.closeSync(fd); } catch(error){if(error.code!=='EEXIST')throw error;}
  fs.chmodSync(dbPath,0o600);
  sqlite = new Database(dbPath);
} catch (e) {
  console.error('FATAL: cannot open database at', dbPath, e.message);
  throw e;
}

// اگر فایل WAL از قبل وجود دارد، داده‌ها را داخل فایل اصلی منتقل کن
try {
  sqlite.pragma('wal_checkpoint(TRUNCATE)');
} catch (e) {
  console.log('wal_checkpoint:', e.message);
}

// حالت DELETE + FULL برای پایداری روی Volume شبکه/دیسک پایدار
sqlite.pragma('journal_mode = DELETE');
sqlite.pragma('synchronous = FULL');
sqlite.pragma('foreign_keys = ON');
sqlite.pragma('busy_timeout = 5000');

/** شبیه‌ساز API کلادفلر D1 روی better-sqlite3 */
function prepare(sql) {
  const stmt = sqlite.prepare(sql);
  const binder = {
    _params: [],
    bind(...params) {
      this._params = params;
      return this;
    },
    first() {
      try {
        return stmt.get(...this._params) || null;
      } catch (e) {
        console.error('db.first', e.message);
        throw e;
      }
    },
    all() {
      try {
        const results = stmt.all(...this._params);
        return { results };
      } catch (e) {
        console.error('db.all', e.message);
        throw e;
      }
    },
    run() {
      try {
        const info = stmt.run(...this._params);
        return {
          success: true,
          meta: { changes: info.changes, last_row_id: info.lastInsertRowid }
        };
      } catch (e) {
        console.error('db.run', e.message);
        throw e;
      }
    }
  };
  return binder;
}

function batch(statements) {
  const run = sqlite.transaction(() => {
    for (const s of statements) {
      if (s && typeof s.run === 'function') s.run();
      else if (s && s._params !== undefined) {
        s.run();
      }
    }
  });
  run();
  return Promise.resolve();
}

const db = {
  prepare,
  batch: (stmts) => {
    const tx = sqlite.transaction(() => {
      for (const s of stmts) {
        if (typeof s.run === 'function') s.run();
      }
    });
    tx();
    return Promise.resolve();
  }
};

let _schemaReady = false;

function ensureSchema() {
  if (_schemaReady) return;
  sqlite.exec(`
    CREATE TABLE IF NOT EXISTS schools (
      id TEXT PRIMARY KEY,
      code TEXT,
      manager_username TEXT,
      data TEXT NOT NULL,
      updated_at INTEGER
    );
    CREATE TABLE IF NOT EXISTS app_data (
      school_id TEXT PRIMARY KEY,
      data TEXT NOT NULL,
      updated_at INTEGER
    );
    CREATE TABLE IF NOT EXISTS submissions (
      id TEXT NOT NULL,
      school_id TEXT NOT NULL,
      assign_id TEXT,
      teacher_id TEXT,
      date TEXT,
      data TEXT NOT NULL,
      created_at INTEGER,
      PRIMARY KEY (school_id, id)
    );
    CREATE TABLE IF NOT EXISTS attendance_records (
      id TEXT PRIMARY KEY,
      school_id TEXT NOT NULL,
      student_id TEXT,
      date TEXT,
      type TEXT,
      data TEXT NOT NULL,
      updated_at INTEGER
    );
    CREATE TABLE IF NOT EXISTS school_soft_meta (
      school_id TEXT PRIMARY KEY,
      deleted_attendance_ids TEXT,
      deleted_submission_ids TEXT,
      updated_at INTEGER
    );
    CREATE INDEX IF NOT EXISTS idx_schools_code ON schools(code);
    CREATE INDEX IF NOT EXISTS idx_schools_user ON schools(manager_username);
    CREATE INDEX IF NOT EXISTS idx_sub_school ON submissions(school_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_att_school ON attendance_records(school_id, date);
    CREATE INDEX IF NOT EXISTS idx_att_student ON attendance_records(school_id, student_id);
  `);
  // Upgrade existing databases without discarding queued submissions.
  const columns = sqlite.pragma('table_info(submissions)');
  if (columns.filter(c => c.pk).length === 1) {
    sqlite.transaction(() => {
      sqlite.exec(`ALTER TABLE submissions RENAME TO submissions_legacy;
        CREATE TABLE submissions (id TEXT NOT NULL, school_id TEXT NOT NULL, assign_id TEXT,
          teacher_id TEXT, date TEXT, data TEXT NOT NULL, created_at INTEGER, PRIMARY KEY (school_id, id));
        INSERT INTO submissions SELECT id, school_id, assign_id, teacher_id, date, data, created_at FROM submissions_legacy;
        DROP TABLE submissions_legacy;
        CREATE INDEX idx_sub_school ON submissions(school_id, created_at);`);
    })();
  }
  _schemaReady = true;
}

ensureSchema();
console.log('=== SCHEMA READY ===');

module.exports = { db, sqlite, ensureSchema, dbPath };
