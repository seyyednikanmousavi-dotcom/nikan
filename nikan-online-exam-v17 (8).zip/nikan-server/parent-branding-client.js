/* Appearance must never block login or create periodic polling. */
(function(){
'use strict';
const schema=window.NikanParentBranding;if(!schema)return;
let pending=null;
function refresh(){
 if(pending)return pending;
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),7000);
 pending=(async()=>{try{const response=await fetch('/api/parent-branding',{cache:'no-store',credentials:'omit',signal:controller.signal});if(!response.ok)return;const data=await response.json();if(data&&data.ok&&data.branding)schema.apply(document.body,data.branding,true);}catch{}finally{clearTimeout(timer);pending=null;}})();
 return pending;
}
window.addEventListener('pageshow',refresh);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh();});
refresh();
})();
