/* Online Exam module for Nikan - standalone, non-destructive */
(function (global) {
  'use strict';

  function toast(msg) {
    try {
      if (typeof global.toast === 'function') return global.toast(msg);
    } catch (e) {}
    try { console.log('[oe]', msg); } catch (e2) {}
  }

  function schoolData() {
    return global.schoolData || (global.schoolData = {});
  }

  function uid() {
    if (typeof global.uid === 'function') return global.uid();
    return 'oe_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  }

  function escapeHtml(s) {
    if (typeof global.escapeHtml === 'function') return global.escapeHtml(s);
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function oeDigits(v) {
    var s = String(v == null ? '' : v).trim();
    if (typeof global.toEnDigits === 'function') s = global.toEnDigits(s);
    else {
      var fa = '۰۱۲۳۴۵۶۷۸۹';
      s = s.replace(/[۰-۹]/g, function (d) { return String(fa.indexOf(d)); });
    }
    var n = parseInt(s, 10);
    return isNaN(n) ? 0 : n;
  }

  function oeEnsure() {
    var sd = schoolData();
    if (!Array.isArray(sd.onlineExams)) sd.onlineExams = [];
    if (!Array.isArray(sd.onlineExamAttempts)) sd.onlineExamAttempts = [];
  }

  function oeCanCreateExam() {
    try {
      if (typeof global.isManager === 'function' && global.isManager()) return true;
      if (typeof global.isTeacher === 'function' && global.isTeacher()) return true;
      if (typeof global.canManage === 'function' && global.canManage()) return true;
    } catch (e) {}
    return false;
  }

  function oeTeacherList() {
    var list = [];
    var seenId = {};
    var seenName = {};
    function normName(n) { return String(n || '').replace(/\s+/g, ' ').trim().toLowerCase(); }
    function add(id, name) {
      id = String(id || '').trim();
      name = String(name || '').replace(/\s+/g, ' ').trim();
      if (!name) return;
      if (id && seenId[id]) return;
      if (seenName[normName(name)]) return;
      if (id) seenId[id] = true;
      seenName[normName(name)] = true;
      list.push({ id: id || ('name_' + normName(name).replace(/\s/g, '_')), name: name });
    }
    var sd = schoolData();
    (sd.staff || []).forEach(function (u) {
      if (!u) return;
      var role = String(u.role || '');
      if (role === 'deputy' || role === 'معاون' || role === 'manager' || role === 'مدیر') return;
      if (role && role !== 'teacher' && role !== 'معلم' && role !== 'دبیر') return;
      add(u.id, u.name || u.username);
    });
    (sd.assignments || []).forEach(function (a) {
      if (!a) return;
      add(a.teacherId || a.staffId || '', a.teacherName || a.staffName || '');
    });
    list.sort(function (a, b) { return String(a.name).localeCompare(String(b.name), 'fa'); });
    return list;
  }

  function oeSubjectList() {
    var set = {};
    var sd = schoolData();
    (sd.assignments || []).forEach(function (a) {
      var s = String(a.subject || a.lesson || a.course || '').trim();
      if (s) set[s] = true;
    });
    (sd.onlineExams || []).forEach(function (ex) {
      var s = String(ex.subject || '').trim();
      if (s) set[s] = true;
    });
    return Object.keys(set).sort(function (a, b) { return a.localeCompare(b, 'fa'); });
  }

  function oeClassOptions() {
    try {
      if (typeof global.classesForRole === 'function') return global.classesForRole() || [];
    } catch (e) {}
    return (schoolData().classes || []).slice();
  }

  function oeFillTeachers() {
    var sel = document.getElementById('oe-teacher');
    if (!sel) return;
    var cur = sel.value;
    var list = oeTeacherList();
    sel.innerHTML = list.map(function (t) {
      return '<option value="' + escapeHtml(t.id) + '">' + escapeHtml(t.name) + '</option>';
    }).join('');
    if (cur) sel.value = cur;
    try {
      if (typeof global.isTeacher === 'function' && global.isTeacher() && global.userSession) {
        var my = String(global.userSession.staffId || global.userSession.id || '');
        if (my) {
          sel.value = my;
          sel.disabled = !((typeof global.isManager === 'function') && global.isManager());
        }
      } else {
        sel.disabled = false;
      }
    } catch (e) {}
  }

  function oeFillClasses() {
    var sel = document.getElementById('oe-class');
    if (!sel) return;
    var cur = sel.value;
    var list = oeClassOptions();
    sel.innerHTML = list.map(function (c) {
      return '<option value="' + escapeHtml(c.id) + '">' + escapeHtml(c.name || c.id) + '</option>';
    }).join('');
    if (cur) sel.value = cur;
  }

  function oeFillSubjects() {
    var dl = document.getElementById('oe-subject-list');
    if (!dl) return;
    dl.innerHTML = oeSubjectList().map(function (s) {
      return '<option value="' + escapeHtml(s) + '"></option>';
    }).join('');
  }

  function oeSetNowStart() {
    try {
      var now = new Date();
      var j;
      if (typeof global.gregorianToJalali === 'function') {
        j = global.gregorianToJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());
      } else {
        j = [now.getFullYear(), now.getMonth() + 1, now.getDate()];
      }
      function set(id, v) {
        var el = document.getElementById(id);
        if (!el) return;
        el.value = (typeof global.toFaDigits === 'function') ? global.toFaDigits(String(v)) : String(v);
      }
      set('oe-sy', j[0]); set('oe-sm', j[1]); set('oe-sd', j[2]);
      var timeEl = document.getElementById('oe-time');
      if (timeEl) timeEl.value = ('0' + now.getHours()).slice(-2) + ':' + ('0' + now.getMinutes()).slice(-2);
      var sh = document.getElementById('oe-sh'); if (sh) sh.value = String(now.getHours());
      var sm = document.getElementById('oe-smin'); if (sm) sm.value = String(now.getMinutes());
      toast('تاریخ و ساعت دستگاه تنظیم شد');
    } catch (e) {
      toast('تنظیم ساعت ناموفق');
    }
  }

  function oeJalaliToIsoStart() {
    var jy = oeDigits(document.getElementById('oe-sy') && document.getElementById('oe-sy').value);
    var jm = oeDigits(document.getElementById('oe-sm') && document.getElementById('oe-sm').value);
    var jd = oeDigits(document.getElementById('oe-sd') && document.getElementById('oe-sd').value);
    var timeEl = document.getElementById('oe-time');
    var hh = 0, mm = 0;
    if (timeEl && timeEl.value) {
      var tp = String(timeEl.value).split(':');
      hh = parseInt(tp[0], 10) || 0;
      mm = parseInt(tp[1], 10) || 0;
    } else {
      hh = oeDigits(document.getElementById('oe-sh') && document.getElementById('oe-sh').value);
      mm = oeDigits(document.getElementById('oe-smin') && document.getElementById('oe-smin').value);
    }
    if (!jy || !jm || !jd) return '';
    try {
      var g;
      if (typeof global.jalaliToGregorian === 'function') g = global.jalaliToGregorian(jy, jm, jd);
      else g = [jy, jm, jd];
      return g[0] + '-' + ('0' + g[1]).slice(-2) + '-' + ('0' + g[2]).slice(-2) + 'T' + ('0' + hh).slice(-2) + ':' + ('0' + mm).slice(-2);
    } catch (e) { return ''; }
  }

  function oeStartAtMsFromForm() {
    var jy = oeDigits(document.getElementById('oe-sy') && document.getElementById('oe-sy').value);
    var jm = oeDigits(document.getElementById('oe-sm') && document.getElementById('oe-sm').value);
    var jd = oeDigits(document.getElementById('oe-sd') && document.getElementById('oe-sd').value);
    var timeEl = document.getElementById('oe-time');
    var hh = 0, mm = 0;
    if (timeEl && timeEl.value) {
      var tp = String(timeEl.value).split(':');
      hh = parseInt(tp[0], 10) || 0; mm = parseInt(tp[1], 10) || 0;
    } else {
      hh = oeDigits(document.getElementById('oe-sh') && document.getElementById('oe-sh').value);
      mm = oeDigits(document.getElementById('oe-smin') && document.getElementById('oe-smin').value);
    }
    if (!jy || !jm || !jd) return 0;
    try {
      var g;
      if (typeof global.jalaliToGregorian === 'function') g = global.jalaliToGregorian(jy, jm, jd);
      else g = [jy, jm, jd];
      return new Date(g[0], g[1] - 1, g[2], hh, mm, 0, 0).getTime();
    } catch (e) { return 0; }
  }

  function oeFillJalaliStart(iso) {
    ['oe-sy', 'oe-sm', 'oe-sd', 'oe-sh', 'oe-smin'].forEach(function (id) {
      var el = document.getElementById(id); if (el) el.value = '';
    });
    var timeEl = document.getElementById('oe-time'); if (timeEl) timeEl.value = '';
    if (!iso) return;
    try {
      var s = String(iso);
      var datePart = s.slice(0, 10);
      var timePart = s.indexOf('T') >= 0 ? s.split('T')[1] : '00:00';
      var p = datePart.split('-');
      var j;
      if (typeof global.gregorianToJalali === 'function') j = global.gregorianToJalali(+p[0], +p[1], +p[2]);
      else j = [+p[0], +p[1], +p[2]];
      var hm = timePart.split(':');
      function set(id, v) {
        var el = document.getElementById(id);
        if (el) el.value = (typeof global.toFaDigits === 'function') ? global.toFaDigits(String(v)) : String(v);
      }
      set('oe-sy', j[0]); set('oe-sm', j[1]); set('oe-sd', j[2]);
      var hh = parseInt(hm[0], 10) || 0, mm = parseInt(hm[1], 10) || 0;
      set('oe-sh', hh); set('oe-smin', mm);
      if (timeEl) timeEl.value = ('0' + hh).slice(-2) + ':' + ('0' + mm).slice(-2);
    } catch (e) {}
  }

  function oeRenderQuestions() {
    var box = document.getElementById('oe-questions');
    if (!box) return;
    var qs = global._oeQuestions || [];
    if (!qs.length) {
      box.innerHTML = '<p class="hint">هنوز سوالی نیست</p>';
      return;
    }
    box.innerHTML = qs.map(function (q, i) {
      var opts = q.options || ['', '', '', ''];
      var head = '<div class="card" style="margin:8px 0"><div class="card-title">سوال ' + (i + 1) +
        ' <button type="button" class="btn btn-danger btn-sm" style="float:left" onclick="oeRemoveQuestion(' + i + ')">حذف</button></div>' +
        '<div class="form-group"><label>متن سوال</label><textarea class="form-control" rows="2" onchange="window._oeQuestions[' + i + '].text=this.value">' + escapeHtml(q.text || '') + '</textarea></div>' +
        '<div class="form-group"><label>نمره</label><input class="form-control" type="number" value="' + (q.score || 1) + '" onchange="window._oeQuestions[' + i + '].score=parseFloat(this.value)||1" /></div>' +
        '<div class="form-group"><label>نوع</label><select class="form-control" onchange="window._oeQuestions[' + i + '].type=this.value;oeRenderQuestions()">' +
        '<option value="mcq"' + ((q.type || 'mcq') === 'mcq' ? ' selected' : '') + '>چهارگزینه‌ای</option>' +
        '<option value="text"' + (q.type === 'text' ? ' selected' : '') + '>تشریحی</option></select></div>';
      if ((q.type || 'mcq') === 'text') {
        return head + '</div>';
      }
      var body = '<p class="hint" style="margin:6px 0;color:#1d4ed8">گزینه صحیح را مشخص کنید (دانش‌آموز نمی‌بیند کدام درست است)</p>' +
        [0, 1, 2, 3].map(function (oi) {
          var letters = ['الف', 'ب', 'ج', 'د'];
          var checked = Number(q.answer) === oi;
          return '<div class="form-group" style="border:1px solid ' + (checked ? '#86efac' : '#e2e8f0') + ';border-radius:10px;padding:8px;margin:6px 0;background:' + (checked ? '#f0fdf4' : '#fff') + '">' +
            '<label style="display:flex;gap:8px;align-items:center"><input type="radio" name="oe-ans-' + i + '" ' + (checked ? 'checked' : '') +
            ' onchange="window._oeQuestions[' + i + '].answer=' + oi + ';oeRenderQuestions()" /> <strong>صحیح: ' + letters[oi] + '</strong></label>' +
            '<input class="form-control" placeholder="متن گزینه ' + letters[oi] + '" value="' + escapeHtml(opts[oi] || '') +
            '" onchange="window._oeQuestions[' + i + '].options[' + oi + ']=this.value" /></div>';
        }).join('');
      return head + body + '</div>';
    }).join('');
  }

  function oeAddQuestion(type) {
    oeEnsure();
    global._oeQuestions = global._oeQuestions || [];
    global._oeQuestions.push({
      id: uid(),
      type: type || 'mcq',
      text: '',
      score: type === 'text' ? 2 : 1,
      options: ['', '', '', ''],
      answer: 0
    });
    oeRenderQuestions();
  }

  function oeRemoveQuestion(i) {
    global._oeQuestions = global._oeQuestions || [];
    global._oeQuestions.splice(i, 1);
    oeRenderQuestions();
  }

  function oeOpenEditor(id) {
    if (!oeCanCreateExam()) return toast('دسترسی ندارید');
    oeEnsure();
    oeFillTeachers();
    oeFillClasses();
    oeFillSubjects();
    global._oeEditingId = id || null;
    var ex = null;
    if (id) {
      ex = (schoolData().onlineExams || []).find(function (x) { return String(x.id) === String(id); });
    }
    document.getElementById('oe-title').value = ex ? (ex.title || '') : '';
    document.getElementById('oe-subject').value = ex ? (ex.subject || '') : '';
    if (ex && ex.teacherId) {
      var tsel = document.getElementById('oe-teacher');
      if (tsel) tsel.value = String(ex.teacherId);
    }
    if (ex && ex.classId) {
      var csel = document.getElementById('oe-class');
      if (csel) csel.value = String(ex.classId);
    }
    document.getElementById('oe-duration').value = ex ? (ex.durationMin || 30) : 30;
    document.getElementById('oe-total').value = ex ? (ex.totalScore || 20) : 20;
    document.getElementById('oe-desc').value = ex ? (ex.description || '') : '';
    ['oe-rand-q', 'oe-rand-o', 'oe-tab', 'oe-gps', 'oe-gps-req'].forEach(function (id) {
      var el = document.getElementById(id);
      if (!el || !ex) return;
      var map = { 'oe-rand-q': 'randomQuestions', 'oe-rand-o': 'randomOptions', 'oe-tab': 'trackTab', 'oe-gps': 'gpsEnabled', 'oe-gps-req': 'gpsRequired' };
      el.checked = !!ex[map[id]];
    });
    var gm = document.getElementById('oe-gps-m');
    if (gm) gm.value = ex && ex.gpsMeters != null ? ex.gpsMeters : 80;
    oeFillJalaliStart(ex && ex.startAt ? ex.startAt : '');
    global._oeQuestions = ex && Array.isArray(ex.questions) ? JSON.parse(JSON.stringify(ex.questions)) : [];
    oeRenderQuestions();
    var title = document.getElementById('oe-edit-title');
    if (title) title.textContent = ex ? 'ویرایش آزمون' : 'تعریف آزمون';
    if (typeof global.showAppPage === 'function') global.showAppPage('online-exam-edit');
  }

  function oeSave(publish) {
    if (!oeCanCreateExam()) return toast('دسترسی ندارید');
    oeEnsure();
    var title = String(document.getElementById('oe-title').value || '').trim();
    if (!title) return toast('عنوان را وارد کنید');
    var qs = (global._oeQuestions || []).filter(function (q) { return String(q.text || '').trim(); });
    if (!qs.length) return toast('حداقل یک سوال لازم است');
    var startAt = oeJalaliToIsoStart();
    var startAtMs = oeStartAtMsFromForm();
    if (!startAtMs && startAt) {
      var t = Date.parse(startAt);
      if (!isNaN(t)) startAtMs = t;
    }
    var id = global._oeEditingId || uid();
    var prev = (schoolData().onlineExams || []).find(function (x) { return String(x.id) === String(id); });
    var teacherEl = document.getElementById('oe-teacher');
    var teacherId = teacherEl ? String(teacherEl.value || '') : '';
    var teacherName = '';
    if (teacherEl && teacherEl.selectedIndex >= 0) teacherName = teacherEl.options[teacherEl.selectedIndex].text || '';
    if (!teacherId && global.userSession) {
      teacherId = String(global.userSession.staffId || global.userSession.id || '');
      teacherName = global.userSession.name || global.userSession.username || '';
    }
    var classEl = document.getElementById('oe-class');
    var classId = classEl ? String(classEl.value || '') : '';
    var className = '';
    if (classEl && classEl.selectedIndex >= 0) className = classEl.options[classEl.selectedIndex].text || '';
    var subject = String(document.getElementById('oe-subject').value || '').trim();
    var durationMin = parseInt(document.getElementById('oe-duration').value, 10) || 30;
    var totalScore = parseFloat(document.getElementById('oe-total').value) || 20;
    var description = String(document.getElementById('oe-desc').value || '').trim();
    var rec = {
      id: id,
      title: title,
      teacherId: teacherId,
      teacherName: teacherName,
      subject: subject,
      classId: classId,
      className: className,
      startAt: startAt,
      startAtMs: startAtMs || 0,
      durationMin: durationMin,
      totalScore: totalScore,
      description: description,
      questions: qs.map(function (q) {
        return {
          id: q.id || uid(),
          type: q.type || 'mcq',
          text: String(q.text || '').trim(),
          score: parseFloat(q.score) || 1,
          options: (q.options || ['', '', '', '']).slice(0, 4),
          answer: Number(q.answer) || 0
        };
      }),
      randomQuestions: !!(document.getElementById('oe-rand-q') && document.getElementById('oe-rand-q').checked),
      randomOptions: !!(document.getElementById('oe-rand-o') && document.getElementById('oe-rand-o').checked),
      trackTab: !!(document.getElementById('oe-tab') && document.getElementById('oe-tab').checked),
      gpsEnabled: !!(document.getElementById('oe-gps') && document.getElementById('oe-gps').checked),
      gpsRequired: !!(document.getElementById('oe-gps-req') && document.getElementById('oe-gps-req').checked),
      gpsMeters: parseInt((document.getElementById('oe-gps-m') && document.getElementById('oe-gps-m').value) || '80', 10) || 80,
      published: publish ? true : !!(prev && prev.published && !publish ? prev.published : false),
      createdAt: prev && prev.createdAt ? prev.createdAt : Date.now(),
      updatedAt: Date.now()
    };
    if (publish) rec.published = true;
    if (!publish && prev) rec.published = !!prev.published;
    if (arguments[0] === false && !prev) rec.published = false;
    if (publish === false) rec.published = false;
    if (publish === true) rec.published = true;
    if (publish !== true && publish !== false && prev) rec.published = !!prev.published;

    var list = schoolData().onlineExams || [];
    var idx = list.findIndex(function (x) { return String(x.id) === String(id); });
    if (idx >= 0) list[idx] = rec; else list.push(rec);
    schoolData().onlineExams = list;
    schoolData()._cloudUpdatedAtMs = Date.now();
    schoolData()._localDirtyAt = Date.now();
    try {
      if (typeof global.markIntentionalSave === 'function') global.markIntentionalSave('soft');
    } catch (e) {}
    try {
      if (typeof global.saveSchoolData === 'function') global.saveSchoolData();
    } catch (e2) {}
    toast(rec.published ? 'آزمون منتشر و ذخیره شد' : 'پیش‌نویس ذخیره شد');
    if (typeof global.showAppPage === 'function') global.showAppPage('online-exams');
    renderOnlineExamsPage();
  }

  function renderOnlineExamsPage() {
    oeEnsure();
    oeFillTeachers();
    var box = document.getElementById('oe-list');
    if (!box) return;
    var list = (schoolData().onlineExams || []).slice();
    try {
      if (typeof global.isTeacher === 'function' && global.isTeacher() && !(typeof global.isManager === 'function' && global.isManager())) {
        var my = String((global.userSession && (global.userSession.staffId || global.userSession.id)) || '');
        list = list.filter(function (ex) { return String(ex.teacherId || '') === my; });
      }
    } catch (e) {}
    list.sort(function (a, b) { return (b.updatedAt || 0) - (a.updatedAt || 0); });
    if (!list.length) {
      box.innerHTML = '<p class="hint">آزمونی نیست — «آزمون جدید» را بزنید</p>';
      return;
    }
    box.innerHTML = list.map(function (ex) {
      var st = ex.published ? '<span class="badge badge-ok">منتشر</span>' : '<span class="badge">پیش‌نویس</span>';
      return '<div class="list-item" style="flex-wrap:wrap;gap:8px">' +
        '<div style="flex:1"><div class="name">' + escapeHtml(ex.title || '') + ' ' + st + '</div>' +
        '<div class="meta">' + escapeHtml(ex.subject || '') + ' · ' + escapeHtml(ex.className || ex.classId || '') +
        ' · ' + escapeHtml(ex.teacherName || '') + ' · سوال: ' + ((ex.questions || []).length) + '</div></div>' +
        '<button class="btn btn-outline btn-sm" onclick="oeOpenEditor(\'' + String(ex.id).replace(/'/g, '') + '\')">ویرایش</button>' +
        '<button class="btn btn-primary btn-sm" onclick="oePublish(\'' + String(ex.id).replace(/'/g, '') + '\',true)">انتشار</button>' +
        '<button class="btn btn-outline btn-sm" onclick="oeOpenMonitor(\'' + String(ex.id).replace(/'/g, '') + '\')">نظارت</button>' +
        '<button class="btn btn-danger btn-sm" onclick="oeDelete(\'' + String(ex.id).replace(/'/g, '') + '\')">حذف</button>' +
        '</div>';
    }).join('');
  }

  function oePublish(id, on) {
    oeEnsure();
    var list = schoolData().onlineExams || [];
    var ex = list.find(function (x) { return String(x.id) === String(id); });
    if (!ex) return toast('پیدا نشد');
    ex.published = !!on;
    ex.updatedAt = Date.now();
    schoolData()._cloudUpdatedAtMs = Date.now();
    try { if (typeof global.markIntentionalSave === 'function') global.markIntentionalSave('soft'); } catch (e) {}
    try { if (typeof global.saveSchoolData === 'function') global.saveSchoolData(); } catch (e2) {}
    toast(on ? 'منتشر شد' : 'از انتشار خارج شد');
    renderOnlineExamsPage();
  }

  function oeDelete(id) {
    if (!confirm('حذف این آزمون؟')) return;
    oeEnsure();
    schoolData().onlineExams = (schoolData().onlineExams || []).filter(function (x) { return String(x.id) !== String(id); });
    schoolData()._cloudUpdatedAtMs = Date.now();
    try { if (typeof global.markIntentionalSave === 'function') global.markIntentionalSave('soft'); } catch (e) {}
    try { if (typeof global.saveSchoolData === 'function') global.saveSchoolData(); } catch (e2) {}
    toast('حذف شد');
    renderOnlineExamsPage();
  }

  function oeOpenMonitor(id) {
    oeEnsure();
    var ex = (schoolData().onlineExams || []).find(function (x) { return String(x.id) === String(id); });
    var box = document.getElementById('oe-monitor-out') || document.getElementById('oe-monitor-list');
    var title = document.getElementById('oe-monitor-title');
    if (title) title.textContent = 'نظارت: ' + ((ex && ex.title) || '');
    var attempts = (schoolData().onlineExamAttempts || []).filter(function (a) { return String(a.examId) === String(id); });
    if (typeof global.showAppPage === 'function') global.showAppPage('online-exam-monitor');
    if (!box) return;
    if (!attempts.length) {
      box.innerHTML = '<p class="hint">هنوز شرکتی ثبت نشده</p>';
      return;
    }
    box.innerHTML = attempts.map(function (a) {
      return '<div class="list-item"><div class="name">' + escapeHtml(a.studentName || a.studentId || '') +
        '</div><div class="meta">نمره: ' + (a.score != null ? a.score : '—') +
        ' · تب‌خروج: ' + (a.tabLeaves || 0) +
        (a.gps ? (' · GPS: ' + Number(a.gps.lat).toFixed(4) + ',' + Number(a.gps.lng).toFixed(4)) : '') +
        '</div></div>';
    }).join('');
  }

  function oeParseTextToQuestions(text) {
    text = String(text || '').replace(/\r/g, '\n');
    text = text.replace(/\u200c/g, '').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n');
    text = text.replace(/(سوال\s*\d+\s*:)/gi, '\n$1');
    text = text.replace(/(نمره\s*:)/gi, '\n$1');
    text = text.replace(/([الفبجد])\s*[\-\.\)\:]/g, '\n$1)');
    text = text.replace(/(پاسخ\s*:)/gi, '\n$1');
    text = text.replace(/(نوع\s*:)/gi, '\n$1');
    var parts = text.split(/(?=^\s*سوال\s*\d+\s*:)/im);
    var qs = [];
    parts.forEach(function (block) {
      block = String(block || '').trim();
      if (!block || !/سوال\s*\d+\s*:/i.test(block)) return;
      var tm = block.match(/سوال\s*\d+\s*:\s*([\s\S]*?)(?=\n\s*نمره\s*:|\n\s*[الفبجد]\s*\)|\n\s*نوع\s*:|$)/i);
      var textQ = tm ? String(tm[1] || '').trim().replace(/\n+/g, ' ') : '';
      var sm = block.match(/نمره\s*:\s*([\d۰-۹\.]+)/i);
      var score = 2;
      if (sm) {
        score = parseFloat(String(sm[1]).replace(/[۰-۹]/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d); })) || 2;
      }
      var isText = /نوع\s*:\s*تشریحی/i.test(block) || !/[الفبجد]\s*\)/.test(block);
      if (isText) {
        if (textQ) qs.push({ id: uid(), type: 'text', text: textQ, score: score || 1, options: [], answer: 0 });
        return;
      }
      var opts = ['', '', '', ''];
      ['الف', 'ب', 'ج', 'د'].forEach(function (L, i) {
        var re = new RegExp(L + '\\s*\\)\\s*([^\\n]+)');
        var m = block.match(re);
        if (m) opts[i] = String(m[1] || '').trim();
      });
      var ans = 0;
      var am = block.match(/پاسخ\s*:\s*([الفبجد])/i);
      if (am) {
        var map = { 'الف': 0, 'ب': 1, 'ج': 2, 'د': 3 };
        ans = map[am[1]] != null ? map[am[1]] : 0;
      }
      if (textQ) qs.push({ id: uid(), type: 'mcq', text: textQ, score: score || 1, options: opts, answer: ans });
    });
    return qs;
  }

  function oeApplyExtractedQuestions(qs) {
    if (!qs || !qs.length) return toast('سوالی استخراج نشد — قالب را بررسی کنید');
    global._oeQuestions = qs;
    oeRenderQuestions();
    toast(qs.length + ' سوال استخراج شد');
    if (typeof global.showAppPage === 'function') global.showAppPage('online-exam-edit');
  }

  function oeLoadImportFile(input, stay) {
    var file = input && input.files && input.files[0];
    if (!file) return;
    var name = String(file.name || '').toLowerCase();
    var reader = new FileReader();
    reader.onload = function () {
      var text = String(reader.result || '');
      if (name.endsWith('.pdf') || (file.type || '').indexOf('pdf') >= 0) {
        if (!global.pdfjsLib) {
          toast('برای PDF کتابخانه pdf.js لازم است — فایل TXT بدهید یا متن را بچسبانید');
          return;
        }
        toast('استخراج PDF در این نسخه با TXT پایدارتر است');
        return;
      }
      var qs = oeParseTextToQuestions(text);
      if (!stay) oeOpenEditor();
      else {
        oeFillTeachers(); oeFillClasses(); oeFillSubjects();
      }
      oeApplyExtractedQuestions(qs);
    };
    reader.readAsText(file);
  }

  function oeQuickUpload(input) {
    oeOpenEditor();
    setTimeout(function () { oeLoadImportFile(input, true); }, 50);
  }

  function oeOpenImport() {
    if (typeof global.showAppPage === 'function') global.showAppPage('online-exam-import');
  }

  // Patch showAppPage once
  function patchShowAppPage() {
    if (global._oeShowPatched) return;
    if (typeof global.showAppPage !== 'function') return;
    var orig = global.showAppPage;
    global.showAppPage = function (name) {
      var r = orig.apply(this, arguments);
      try {
        if (name === 'online-exams') renderOnlineExamsPage();
        if (name === 'online-exam-edit') {
          oeFillTeachers(); oeFillClasses(); oeFillSubjects();
        }
      } catch (e) { console.warn('oe page', e); }
      return r;
    };
    global._oeShowPatched = true;
  }

  function injectHomeButton() {
    try {
      var act = document.getElementById('home-actions');
      if (!act || act.querySelector('[data-oe-home]')) return;
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'qa-item accent';
      btn.setAttribute('data-oe-home', '1');
      btn.onclick = function () { if (typeof global.showAppPage === 'function') global.showAppPage('online-exams'); };
      btn.innerHTML = '<span class="ic">🧪</span><span class="lb">آزمون آنلاین</span><span class="ds">تعریف و انتشار</span>';
      var grid = act.querySelector('.qa-grid');
      if (grid) grid.appendChild(btn);
      else act.appendChild(btn);
    } catch (e) {}
  }

  function patchRenderHome() {
    if (global._oeHomePatched) return;
    if (typeof global.renderHome !== 'function') return;
    var orig = global.renderHome;
    global.renderHome = function () {
      var r = orig.apply(this, arguments);
      try { injectHomeButton(); } catch (e) {}
      return r;
    };
    global._oeHomePatched = true;
  }

  // exports
  global.oeEnsure = oeEnsure;
  global.oeOpenEditor = oeOpenEditor;
  global.oeSave = oeSave;
  global.oePublish = oePublish;
  global.oeDelete = oeDelete;
  global.oeOpenMonitor = oeOpenMonitor;
  global.oeAddQuestion = oeAddQuestion;
  global.oeRemoveQuestion = oeRemoveQuestion;
  global.oeRenderQuestions = oeRenderQuestions;
  global.oeSetNowStart = oeSetNowStart;
  global.oeOpenImport = oeOpenImport;
  global.oeLoadImportFile = oeLoadImportFile;
  global.oeQuickUpload = oeQuickUpload;
  global.renderOnlineExamsPage = renderOnlineExamsPage;

  function boot() {
    patchShowAppPage();
    patchRenderHome();
    injectHomeButton();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
  setTimeout(boot, 1500);
})(window);
