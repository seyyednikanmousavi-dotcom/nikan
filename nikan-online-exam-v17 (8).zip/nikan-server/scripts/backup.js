#!/usr/bin/env node
'use strict';
const fs=require('node:fs'),path=require('node:path'),Database=require('better-sqlite3');
async function main(){
 const argument=process.argv[2];if(!argument||process.argv.length!==3)throw Error('Usage: npm run backup -- /private/path/backup.sqlite');
 const source=path.resolve(process.env.DB_PATH||path.join(process.env.DATA_DIR||path.join(__dirname,'../data'),'nikan.sqlite'));
 const destination=path.resolve(argument);
 if(!fs.existsSync(source))throw Error('Source database does not exist; verify DATA_DIR/DB_PATH.');
 if(destination===source)throw Error('Backup destination must differ from the live database.');
 if(fs.existsSync(destination))throw Error('Destination already exists; choose a new filename.');
 fs.mkdirSync(path.dirname(destination),{recursive:true,mode:0o700});
 let created=false,db;
 try{
  const fd=fs.openSync(destination,'wx',0o600);fs.closeSync(fd);created=true;
  db=new Database(source,{readonly:true,fileMustExist:true});
  await db.backup(destination);
  const check=new Database(destination,{readonly:true,fileMustExist:true});
  try{if(check.pragma('integrity_check',{simple:true})!=='ok'||check.pragma('foreign_key_check').length)throw Error('Backup integrity verification failed.');}finally{check.close();}
  fs.chmodSync(destination,0o600);console.log('Backup completed and SQLite integrity verified. Keep it private and copy it outside the primary disk.');
 }catch(error){if(created)fs.rmSync(destination,{force:true});throw error;}
 finally{if(db)db.close();}
}
main().catch(error=>{console.error(error.message);process.exitCode=1;});
