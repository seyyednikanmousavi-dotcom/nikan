#!/usr/bin/env node
'use strict';
const crypto = require('node:crypto');
const { createInterface } = require('node:readline/promises');
const { Writable } = require('node:stream');

async function credentials() {
  if (process.argv.includes('--stdin')) {
    let input = '';
    for await (const chunk of process.stdin) {
      input += chunk;
      if (Buffer.byteLength(input) > 16384) throw new Error('ورودی بیش از حد بزرگ است');
    }
    try { return JSON.parse(input); } catch { throw new Error('ورودی JSON نامعتبر است'); }
  }
  if (!process.stdin.isTTY) throw new Error('از ترمینال تعاملی یا گزینه --stdin استفاده کنید');
  let hidden = false;
  const output = new Writable({ write(chunk, encoding, done) { if (!hidden) process.stdout.write(chunk); done(); } });
  const rl = createInterface({ input: process.stdin, output, terminal: true });
  try {
    const user = (await rl.question('نام کاربری پنل مادر [admin]: ')).trim() || 'admin';
    process.stdout.write('رمز جدید (حداقل ۶ کاراکتر؛ نمایش داده نمی‌شود): ');
    hidden = true;
    const pass = await rl.question('');
    process.stdout.write('\nتکرار رمز: ');
    const confirm = await rl.question('');
    process.stdout.write('\n');
    if (pass !== confirm) throw new Error('تکرار رمز یکسان نیست');
    return { user, pass };
  } finally { hidden = false; rl.close(); }
}
async function main() {
  if (process.argv.includes('--help')) {
    console.log('npm run mother:setup [-- --reset]\nتنظیم حساب مادر در همان DATA_DIR/DB_PATH سرور؛ --reset برای بازنشانی حساب موجود.\n--stdin: دریافت JSON شامل user و pass از ورودی استاندارد؛ رمز را در آرگومان فرمان ننویسید.');
    return;
  }
  if (process.argv.slice(2).some(arg => !['--stdin', '--reset'].includes(arg))) throw new Error('گزینه نامعتبر است؛ --help را ببینید');
  const input = await credentials();
  const user = input && typeof input.user === 'string' ? input.user.trim() : '';
  const pass = input && typeof input.pass === 'string' ? input.pass : '';
  if (user.length < 3 || user.length > 256 || pass.length < 6 || pass.length > 1024) throw new Error('نام کاربری بین ۳ تا ۲۵۶ و رمز بین ۶ تا ۱۰۲۴ کاراکتر باشد');
  const { sqlite, dbPath } = require('../db');
  try {
    sqlite.transaction(() => {
      const previous = sqlite.prepare('SELECT school_id FROM app_data WHERE school_id=?').get('__mother_auth__');
      if (previous && !process.argv.includes('--reset')) throw new Error('حساب مادر موجود است؛ برای بازنشانی آگاهانه --reset را اضافه کنید');
      const salt = crypto.randomBytes(16).toString('hex');
      const hash = crypto.scryptSync(pass, salt, 64).toString('hex');
      sqlite.prepare('INSERT INTO app_data(school_id,data,updated_at) VALUES(?,?,?) ON CONFLICT(school_id) DO UPDATE SET data=excluded.data,updated_at=excluded.updated_at')
        .run('__mother_auth__', JSON.stringify({ user, salt, hash }), Date.now());
    })();
    console.log('حساب پنل مادر ذخیره شد. با حساب تعیین‌شده در /mother وارد شوید.');
    console.log('دیتابیس: ' + dbPath + '\nاطلاعات مدارس، لایسنس‌ها و امکانات تغییر نکردند.');
  } finally { sqlite.close(); }
}
main().catch(error => { console.error(error.message); process.exitCode = 1; });
