(function(){
'use strict';
const W=window.NikanWebsite,by=id=>document.getElementById(id),el=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;};
let draft=null,revision=0,dirty=false,epoch=0,requestVersion=0,tab='general',offset=0,total=0,requests=[],publishing=false,photoQueue=Promise.resolve();
const photoJobs=new Map();
const labels={new:'جدید',contacted:'در حال پیگیری',completed:'تکمیل‌شده',closed:'بسته‌شده'};
const uid=()=> 'item-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,9);
function status(text){by('ws-status').textContent=text;}
function errorMessage(e){return ({content_too_large:'حجم محتوای سایت زیاد است؛ عکس‌ها یا متن‌ها را کاهش دهید.',content_conflict:'سایت در جای دیگری ویرایش شده است. تغییرات شما حفظ شده؛ پیش از انتشار، نسخهٔ تازه را دریافت و تغییرات را تطبیق دهید.',request_conflict:'این درخواست هم‌زمان تغییر کرده است؛ فهرست را تازه و دوباره بررسی کنید.',forbidden:'ویرایش سایت فقط برای مدیر پنل مادر مجاز است.'})[e.message]||'عملیات انجام نشد؛ اتصال و اطلاعات ورود را بررسی و دوباره تلاش کنید.';}
function mark(){dirty=true;by('ws-dirty').textContent='تغییرات منتشرنشده دارید.';}
function field(label,obj,key,{type='text',max=200,min,numMax,rows,choices,hint,track=true}={}){
 const wrap=el('label','ws-field',label),input=el(choices?'select':rows?'textarea':'input');
 if(choices){for(const [v,t]of choices){const option=el('option','',t);option.value=v;input.append(option);}}else if(!rows)input.type=type;
 if(type==='number'){input.min=String(min===undefined?0:min);if(numMax!==undefined)input.max=String(numMax);input.step='1';}
 input.value=obj[key]===null?'':obj[key]===undefined?'':obj[key];input.dataset.key=key;
 if(rows)input.rows=rows;if(max)input.maxLength=max;
 input.addEventListener(choices?'change':'input',()=>{obj[key]=type==='number'?(input.value===''?null:Number(input.value)):input.value;if(track)mark();});wrap.append(input);if(hint)wrap.append(el('small','ws-hint',hint));return wrap;
}
function checkbox(label,obj,key){const wrap=el('label','ws-checkbox'),input=el('input');input.type='checkbox';input.checked=obj[key];input.addEventListener('change',()=>{obj[key]=input.checked;mark();});wrap.append(input,document.createTextNode(label));return wrap;}
function button(label,action){const b=el('button','',label);b.type='button';b.addEventListener('click',action);return b;}
function lines(label,obj,key,maxChars){const tmp={value:(obj[key]||[]).join('\n')},f=field(label,tmp,'value',{rows:3,max:maxChars||4000});f.querySelector('textarea').addEventListener('input',()=>{obj[key]=tmp.value.split('\n').map(x=>x.trim()).filter(Boolean);});return f;}
function itemShell(key,row,i){const box=el('section','ws-item'),head=el('div','ws-item-head'),actions=el('div');head.append(el('h3','',(i+1)+' · '+(row.name||row.title||row.question||row.label||'مورد')));actions.append(button('↑',()=>move(key,i,-1)),button('↓',()=>move(key,i,1)),button('حذف',()=>{if(confirm('این مورد از سایت حذف شود؟')){draft[key].splice(i,1);mark();renderTab();}}));head.append(actions);box.append(head);return box;}
function move(k,i,delta){const j=i+delta;if(j<0||j>=draft[k].length)return;[draft[k][i],draft[k][j]]=[draft[k][j],draft[k][i]];mark();renderTab();}
function renderGeneral(pane){
 pane.append(checkbox('نمایش انیمیشن‌های ظریف سایت',draft,'animations'),el('p','ws-hint','تنظیم کاهش حرکت دستگاه بازدیدکننده همیشه رعایت می‌شود.'));
 const grid=el('div','ws-grid');for(const [k,m]of Object.entries(W.texts))grid.append(field(m[0],draft,k,{max:m[2],rows:m[2]>160?3:undefined}));pane.append(grid);
 const theme=el('div','ws-grid');for(const [k,t]of [['primary','رنگ سرمه‌ای / اصلی'],['accent','رنگ تأکیدی'],['gold','رنگ طلایی'],['background','زمینه سایت']])theme.append(field(t,draft.theme,k,{type:'color'}));pane.append(theme);
 const logo=el('div','ws-actions'),image=el('img');image.id='ws-logo-preview';image.src=draft.logo||'/favicon.svg';image.alt='نشان سایت';const upload=el('input');upload.type='file';upload.accept='image/png,image/jpeg,image/webp';upload.setAttribute('aria-label','نشان سایت');
 upload.addEventListener('change',()=>{const file=upload.files[0],generation=epoch;if(!file)return;if(file.size>5*1024*1024||!['image/png','image/jpeg','image/webp'].includes(file.type)){status('نشان باید PNG، JPEG یا WebP و حداکثر۵ مگابایت باشد.');return;}
 const url=URL.createObjectURL(file),img=new Image();const release=()=>{URL.revokeObjectURL(url);img.src='';};img.onerror=()=>{release();status('خواندن نشان ممکن نشد.');};img.onload=()=>{try{if(generation!==epoch||!draft)return;const c=document.createElement('canvas'),scale=Math.min(1,320/Math.max(img.width,img.height));c.width=Math.max(1,Math.round(img.width*scale));c.height=Math.max(1,Math.round(img.height*scale));c.getContext('2d').drawImage(img,0,0,c.width,c.height);const data=c.toDataURL('image/webp',.85);c.width=c.height=0;if(data.length>220000){status('نشان هنوز بزرگ است؛ تصویر ساده‌تری انتخاب کنید.');return;}draft.logo=data;image.src=data;mark();}finally{img.onload=img.onerror=null;release();}};img.src=url;});
 logo.append(image,upload,button('حذف نشان سفارشی',()=>{draft.logo='';image.src='/favicon.svg';mark();}));pane.append(el('h3','','نشان سایت'),logo);
}
function syncSave(){by('ws-save').disabled=publishing||photoJobs.size>0;}
function compressPhoto(file){
 return new Promise((resolve,reject)=>{
  if(!file||!['image/png','image/jpeg','image/webp'].includes(file.type)||file.size>10*1024*1024)return reject(Error('عکس باید PNG، JPEG یا WebP و حداکثر۱۰ مگابایت باشد.'));
  const src=URL.createObjectURL(file),img=new Image();let canvas;
  const release=()=>{img.onload=img.onerror=null;img.src='';URL.revokeObjectURL(src);if(canvas)canvas.width=canvas.height=0;};
  img.onerror=()=>{release();reject(Error('خواندن این تصویر ممکن نشد؛ تصویر دیگری انتخاب کنید.'));};
  img.onload=()=>{try{
   if(!img.width||!img.height||img.width*img.height>24000000)throw Error('ابعاد عکس بیش از حد بزرگ است؛ عکس کوچک‌تری انتخاب کنید.');
   canvas=document.createElement('canvas');const scale=Math.min(1,1440/Math.max(img.width,img.height));canvas.width=Math.max(1,Math.round(img.width*scale));canvas.height=Math.max(1,Math.round(img.height*scale));
   const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0,canvas.width,canvas.height);
   let data='';for(const quality of [.84,.7,.55,.4]){data=canvas.toDataURL('image/jpeg',quality);if(data.length<=W.MAX_PHOTO_LENGTH)break;}
   if(data.length>W.MAX_PHOTO_LENGTH)throw Error('این تصویر هنوز بزرگ است؛ عکس ساده‌تر یا کوچک‌تری انتخاب کنید.');resolve(data);
  }catch(e){reject(e);}finally{release();}};img.src=src;
 });
}
function queuePhoto(row,file){
 const token=Symbol(),generation=epoch;photoJobs.set(row.id,token);syncSave();status('در حال آماده‌سازی عکس‌ها…');
 photoQueue=photoQueue.catch(()=>{}).then(async()=>{
  if(generation!==epoch||photoJobs.get(row.id)!==token||!draft?.heroSlides.includes(row))return;
  try{const image=await compressPhoto(file);if(generation!==epoch||photoJobs.get(row.id)!==token||!draft?.heroSlides.includes(row))return;row.image=image;mark();if(tab==='slides')renderTab();status('عکس آماده شد؛ برای نمایش عمومی، سایت را منتشر کنید.');}catch(e){if(generation===epoch&&photoJobs.get(row.id)===token)status(e.message);}
 }).finally(()=>{if(photoJobs.get(row.id)===token)photoJobs.delete(row.id);if(generation===epoch)syncSave();});
}
function renderSlides(pane){
 pane.append(el('p','ws-hint','تا۶ عکس برای ابتدای سایت انتخاب کنید. عکس‌ها پیش از ذخیره کوچک و فشرده می‌شوند؛ تصویر اولیه تا۱۰ مگابایت و PNG/JPEG/WebP پذیرفته است. با حذف همهٔ عکس‌ها، نمای پیش‌فرض سامانه نمایش داده می‌شود.'));
 draft.heroSlides.forEach((row,i)=>{const box=itemShell('heroSlides',row,i),preview=el('img','ws-photo-preview');preview.alt=row.title||'پیش‌نمایش عکس معرفی';if(row.image)preview.src=row.image;else preview.hidden=true;box.append(preview,field('عنوان و توضیح جایگزین عکس',row,'title',{max:100}),field('توضیح زیر عکس',row,'caption',{rows:2,max:250}));
  const replace=el('input');replace.type='file';replace.accept='image/png,image/jpeg,image/webp';replace.setAttribute('aria-label','جایگزینی عکس '+(i+1));replace.addEventListener('change',()=>{if(replace.files[0])queuePhoto(row,replace.files[0]);});box.append(el('p','ws-hint','جایگزینی این عکس'),replace);pane.append(box);
 });
 const add=el('input');add.type='file';add.multiple=true;add.accept='image/png,image/jpeg,image/webp';add.setAttribute('aria-label','افزودن عکس‌های معرفی');add.addEventListener('change',()=>{const room=6-draft.heroSlides.length,files=Array.from(add.files);if(files.length>room)status('حداکثر۶ عکس قابل تعریف است. فقط عکس‌های تا سقف ظرفیت اضافه می‌شوند.');for(const file of files.slice(0,room)){const row={id:uid(),title:'',caption:'',image:''};draft.heroSlides.push(row);mark();queuePhoto(row,file);}renderTab();});add.disabled=draft.heroSlides.length>=6;pane.append(el('h3','','افزودن عکس'),add);
}
function renderDownloads(pane){
 pane.append(el('p','ws-hint','لینک واقعی دانلود APK یا صفحهٔ نصب در فروشگاه را با HTTPS وارد کنید. تا وقتی لینکی تعریف و منتشر نشود، دکمهٔ نصب در سایت نمایش داده نمی‌شود. این بخش فایل اپ نمی‌سازد؛ دانلود و نصب از مسیر لینک شما انجام می‌شود.'));
 draft.appDownloads.forEach((row,i)=>{const box=itemShell('appDownloads',row,i);box.append(field('عنوان دکمه؛ مثلاً دریافت نسخه اندروید',row,'label',{max:80}),field('توضیح؛ مثلاً دانلود مستقیم یا نام فروشگاه',row,'description',{max:200}),field('لینک نصب / دانلود (HTTPS)',row,'url',{max:1000}),checkbox('نمایش لینک نصب در سایت',row,'visible'));pane.append(box);});
 pane.append(button('＋ افزودن لینک نصب',()=>{if(draft.appDownloads.length>=6)return status('حداکثر۶ لینک نصب قابل تعریف است.');draft.appDownloads.push({id:uid(),label:'دریافت نسخه اندروید',description:'',url:'',visible:true});mark();renderTab();}));
}
function renderPlans(pane){
 pane.append(el('p','ws-hint','قیمت‌ها به تومان‌اند. خالی = استعلام، صفر = رایگان. این تنظیمات بستهٔ سایت هستند؛ مدارس موجود با تغییر بسته دست‌کاری نمی‌شوند. امکانات هنگام ساخت مدرسه از درخواست، وارد فرم مدیریت می‌شوند و پیش از ذخیره قابل بررسی‌اند.'));
 draft.plans.forEach((p,i)=>{const box=itemShell('plans',p,i),grid=el('div','ws-grid');for(const [label,key,opt]of [['نام بسته','name',{max:80}],['توضیح','description',{max:250}],['قیمت (تومان)','price',{type:'number',numMax:1000000000000}],['عنوان دوره؛ مثلاً سالانه','period',{max:45}],['طول دوره (ماه)','months',{type:'number',min:1,numMax:36}],['سقف دانش‌آموز','maxUsers',{type:'number',min:1,numMax:100000}],['شیفت','shifts',{choices:[['1','یک شیفت'],['2','دو شیفت']]}],['برچسب پیشنهادی','badge',{max:50}]]){const f=field(label,p,key,opt);if(key==='shifts')f.querySelector('select').addEventListener('change',e=>{p.shifts=Number(e.target.value);if(p.shifts===2&&!p.modules.includes('dual_shift'))p.modules.push('dual_shift');if(p.shifts===1)p.modules=p.modules.filter(x=>x!=='dual_shift');mark();renderTab();});grid.append(f);}box.append(grid,checkbox('نمایش این بسته در سایت',p,'visible'),el('h4','','قابلیت‌های بسته'));
 const mods=el('div','ws-checks');for(const m of W.modules){const label=el('label'),c=el('input');c.type='checkbox';c.checked=p.modules.includes(m.id);c.dataset.module=m.id;c.addEventListener('change',()=>{p.modules=p.modules.filter(x=>x!==m.id);if(c.checked)p.modules.push(m.id);if(m.id==='dual_shift'){p.shifts=c.checked?2:1;renderTab();}mark();});label.append(c,document.createTextNode(m.label));mods.append(label);}box.append(mods,lines('امکانات توضیحی اضافه؛ هر مورد در یک خط (حداکثر۸ مورد)',p,'extras',1200));pane.append(box);});
 pane.append(button('＋ افزودن بسته',()=>{if(draft.plans.length>=12)return status('حداکثر۱۲ بسته قابل تعریف است.');draft.plans.push({...W.clone(W.defaults.plans[0]),id:uid(),name:'بستهٔ جدید',badge:''});mark();renderTab();}));
}
function renderList(pane,key){
 const specs={features:[['عنوان','title',130],['توضیح','text',350]],tutorials:[['عنوان راهنما','title',140],['نقش مخاطب','audience',70],['توضیح کوتاه','summary',300],['لینک ویدیو (HTTPS اختیاری)','videoUrl',1000]],faqs:[['پرسش','question',200],['پاسخ','answer',1200]],contacts:[['عنوان راه ارتباطی','label',60],['متن نمایشی / شناسه','display',100],['نشانی (https، tel، sms یا mailto)','url',1000]]};
 draft[key].forEach((row,i)=>{const box=itemShell(key,row,i);for(const [name,k,max]of specs[key]){const f=field(name,row,k,{max,rows:max>200&&k!=='url'&&k!=='videoUrl'?3:undefined});if(k==='url'||k==='videoUrl')f.classList.add('ws-url');box.append(f);}if(key==='features')box.append(field('آیکون',row,'icon',{choices:[['attendance','حضور'],['chart','گزارش'],['family','خانواده'],['book','دفتر'],['message','پیام'],['shield','دسترسی']]}));if(key==='tutorials')box.append(lines('مراحل آموزش؛ هر مرحله در یک خط (حداکثر۱۲ مرحله)',row,'steps',7800));pane.append(box);});
 const max={features:12,tutorials:15,faqs:20,contacts:12}[key];pane.append(button('＋ افزودن مورد',()=>{if(draft[key].length>=max)return status('به حداکثر تعداد مجاز رسیده‌اید.');draft[key].push({id:uid(),title:'',text:'',icon:'shield',audience:'',summary:'',steps:[],videoUrl:'',question:'',answer:'',label:'',display:'',url:''});mark();renderTab();}));
}
function renderTab(){
 by('ws-content-pane').hidden=tab==='requests';by('ws-requests-pane').hidden=tab!=='requests';by('ws-publish-toolbar').hidden=tab==='requests';for(const b of document.querySelectorAll('[data-ws-tab]'))b.setAttribute('aria-selected',String(b.dataset.wsTab===tab));
 if(tab==='requests'){loadRequests();return;}const pane=by('ws-content-pane');pane.replaceChildren();if(!draft)return;if(tab==='general')renderGeneral(pane);else if(tab==='slides')renderSlides(pane);else if(tab==='downloads')renderDownloads(pane);else if(tab==='plans')renderPlans(pane);else renderList(pane,tab);
}
async function loadContent(force){
 if(force&&dirty&&!confirm('تغییرات منتشرنشده کنار گذاشته و نسخهٔ سرور دریافت شود؟'))return;
 const generation=++epoch;photoJobs.clear();publishing=false;syncSave();by('ws-controls').disabled=true;status('در حال دریافت تنظیمات سایت…');
 try{const data=await apiFetch('/api/website/manage',{retries:1,timeoutMs:15000});if(generation!==epoch)return;draft=W.clone(data.content);revision=data.updatedAt;dirty=false;by('ws-dirty').textContent='نسخهٔ منتشرشده دریافت شد.';status('');by('ws-controls').disabled=false;renderTab();}catch(e){if(generation===epoch)status(errorMessage(e));}
}
async function publish(e){
 e.preventDefault();if(!draft||publishing)return;if(photoJobs.size)return status('پس از آماده‌شدن همهٔ عکس‌ها، دوباره انتشار را بزنید.');if(draft.heroSlides.some(p=>!p.image))return status('برای هر مورد عکس انتخاب کنید یا مورد خالی را حذف کنید.');if(draft.appDownloads.some(d=>!/^https:\/\//i.test(d.url)||!W.url(d.url)))return status('برای لینک نصب، نشانی کامل و معتبر HTTPS وارد کنید.');const badContact=draft.contacts.find(c=>!W.url(c.url));const badVideo=draft.tutorials.find(t=>t.videoUrl&&(!/^https:\/\//i.test(t.videoUrl)||!W.url(t.videoUrl)));if(badContact||badVideo)return status('نشانی تماس یا ویدیو معتبر نیست. فقط نشانی‌های امن و کامل قابل ذخیره‌اند.');
 const sent=JSON.stringify(draft),generation=epoch;if(new Blob([sent]).size>W.MAX_CONTENT_BYTES)return status('حجم محتوای سایت زیاد است؛ تعداد یا حجم عکس‌ها و متن‌ها را کاهش دهید.');publishing=true;syncSave();status('در حال انتشار…');
 try{const result=await apiFetch('/api/website/manage',{method:'PUT',body:{content:JSON.parse(sent),expectedUpdatedAt:revision},retries:1,timeoutMs:30000});if(generation!==epoch)return;revision=result.updatedAt;if(JSON.stringify(draft)===sent){draft=W.clone(result.content);dirty=false;renderTab();by('ws-dirty').textContent='همهٔ تغییرات منتشر شده‌اند.';}status('✓ سایت منتشر شد. با بازکردن یا تازه‌کردن سایت، نسخهٔ جدید نمایش داده می‌شود.');}catch(error){if(generation===epoch)status(errorMessage(error));}finally{if(generation===epoch){publishing=false;syncSave();}}
}
function schoolFromRequest(r){
 if(!confirm('فرم ساخت مدرسه با اطلاعات این درخواست باز شود؟ فعال‌سازی پس از بررسی و ذخیرهٔ شما انجام می‌شود.'))return;
 openSchoolModal(null);
 for(const [id,v]of [['f-name',r.schoolName],['f-manager',r.managerName],['f-phone',r.phone],['f-city',r.city],['f-maxusers',r.plan.maxUsers],['f-shifts',r.plan.shifts],['f-plan','paid'],['f-notes','درخواست سایت '+r.id+'\nبسته: '+r.plan.name+'\n'+r.message]]){const n=by(id);if(n)n.value=v;}
 for(const n of document.querySelectorAll('.mod-check'))n.checked=r.plan.modules.includes(n.value);
 const start=todayStr(),end=addMonths(start,r.plan.months);for(const [prefix,iso]of [['f-start',start],['f-expire',end]]){const parts=iso.split('-').map(Number),j=gregorianToJalali(...parts);for(const [suffix,v]of [['jy',j[0]],['jm',j[1]],['jd',j[2]]])by(prefix+'-'+suffix).value=String(v);}
 toast('اطلاعات و امکانات بسته وارد فرم شد. تاریخ‌ها، نام کاربری و رمز را بررسی و سپس ذخیره کنید.');
}
async function loadRequests(){
 const generation=epoch,version=++requestVersion;by('ws-request-list').textContent='در حال دریافت…';
 try{const data=await apiFetch('/api/website/requests?status='+encodeURIComponent(by('ws-request-filter').value)+'&offset='+offset,{retries:1});if(generation!==epoch||version!==requestVersion||tab!=='requests')return;if(offset>0&&!data.requests.length&&data.total<=offset){offset=Math.max(0,Math.floor(Math.max(0,data.total-1)/30)*30);return loadRequests();}requests=data.requests;total=data.total;renderRequests();}catch(e){if(generation===epoch&&version===requestVersion&&tab==='requests')by('ws-request-list').textContent=errorMessage(e);}
}
function renderRequests(){
 const root=by('ws-request-list');root.replaceChildren();by('ws-request-count').textContent='تعداد: '+total;by('ws-prev').disabled=offset===0;by('ws-next').disabled=offset+30>=total;if(!requests.length)root.append(el('p','ws-hint','درخواستی در این فهرست نیست.'));
 for(const r of requests){const box=el('article','ws-item'),head=el('div','ws-item-head');head.append(el('h3','',r.schoolName),el('span','badge',labels[r.status]));box.append(head);const meta=el('div','ws-request-meta'),phone=el('a','',r.phone);phone.href='tel:'+r.phone;meta.append(el('span','',r.managerName),phone,el('span','',r.city),el('span','',new Date(r.createdAt).toLocaleString('fa-IR')));box.append(meta,el('p','ws-hint','کد پیگیری: '+r.id));const p=el('div','ws-request-plan');p.append(el('strong','',r.plan.name+' · '+(r.plan.price===null?'استعلام':r.plan.price.toLocaleString('fa-IR')+' تومان')+' · '+r.plan.period),el('p','','تا '+r.plan.maxUsers.toLocaleString('fa-IR')+' دانش‌آموز · '+r.plan.months+' ماه'),el('p','',r.plan.modules.map(id=>W.modules.find(m=>m.id===id)?.label||id).join('، ')));box.append(p,el('p','ws-request-note',r.message));
 const edit={status:r.status,note:r.adminNote||''};box.append(field('وضعیت پیگیری',edit,'status',{choices:Object.entries(labels),track:false}),field('یادداشت خصوصی مدیریت',edit,'note',{rows:3,max:2000,track:false}));const actions=el('div','ws-actions');actions.append(button('ذخیرهٔ پیگیری',async e=>{const generation=epoch;try{const data=await apiFetch('/api/website/requests/'+r.id,{method:'PUT',body:{status:edit.status,note:edit.note,expectedUpdatedAt:r.updatedAt},retries:1});if(generation!==epoch)return;Object.assign(r,data.request);status('پیگیری ذخیره شد.');if(tab==='requests')await loadRequests();}catch(error){if(generation===epoch)status(errorMessage(error));}}),button('ساخت مدرسه از این درخواست',()=>schoolFromRequest(r)));box.append(actions,el('p','ws-hint','ساخت مدرسه خودکار نیست. پس از تأیید شرایط و پرداخت، فرم مدرسه را بررسی و ذخیره کنید و وضعیت درخواست را به‌روزرسانی کنید.'));root.append(box);}
}
window.loadWebsiteIntoMother=function(){if(!draft)loadContent(false);else renderTab();};
window.clearWebsiteManagerState=function(){epoch++;photoJobs.clear();publishing=false;syncSave();draft=null;requests=[];dirty=false;revision=0;offset=0;tab='general';by('ws-content-pane').replaceChildren();by('ws-request-list').replaceChildren();by('ws-controls').disabled=true;status('');by('ws-dirty').textContent='';};
by('ws-editor').addEventListener('submit',publish);by('ws-refresh').addEventListener('click',()=>loadContent(true));for(const b of document.querySelectorAll('[data-ws-tab]'))b.addEventListener('click',()=>{tab=b.dataset.wsTab;renderTab();});by('ws-request-filter').addEventListener('change',()=>{offset=0;loadRequests();});by('ws-refresh-requests').addEventListener('click',loadRequests);by('ws-prev').addEventListener('click',()=>{offset=Math.max(0,offset-30);loadRequests();});by('ws-next').addEventListener('click',()=>{offset+=30;loadRequests();});
window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue='';}});
})();
