(function(){
'use strict';
const W=window.NikanWebsite,by=id=>document.getElementById(id),make=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;};
const icons={attendance:'<rect x="4" y="5" width="16" height="16" rx="3"/><path d="M8 3v4m8-4v4M4 11h16m-12 5 2 2 5-5"/>',chart:'<path d="M4 4v16h17M8 15l4-5 4 3 4-7"/>',family:'<circle cx="8" cy="8" r="3"/><circle cx="17" cy="10" r="2"/><path d="M2 21v-3a6 6 0 0 1 12 0v3m2-5a4 4 0 0 1 6 3v2"/>',book:'<path d="M12 6c-4-3-8-2-10-1v15c4-2 7-1 10 1 3-2 6-3 10-1V5c-3-1-6-2-10 1v15"/>',message:'<path d="M5 4h14a3 3 0 0 1 3 3v9a3 3 0 0 1-3 3H8l-6 3V7a3 3 0 0 1 3-3Z"/><path d="M7 9h10M7 14h7"/>',shield:'<path d="M12 2 3 6v6c0 5 9 10 9 10s9-5 9-10V6Z"/><path d="m8 12 3 3 5-6"/>'};
let config,contentUpdatedAt=0,previousFocus,requestKey='',requestSignature='';
function key(){return typeof crypto.randomUUID==='function'?crypto.randomUUID():Array.from(crypto.getRandomValues(new Uint8Array(24)),n=>n.toString(16).padStart(2,'0')).join('');}
function choosePlan(id){const select=by('request-plan');select.value=id;by('contact').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});by('request-form').elements.schoolName.focus({preventScroll:true});}
function openTutorial(t){previousFocus=document.activeElement;by('tutorial-title').textContent=t.title;by('tutorial-audience').textContent=t.audience;by('tutorial-summary').textContent=t.summary;by('tutorial-steps').replaceChildren(...t.steps.map(s=>make('li','',s)));const v=by('tutorial-video');v.hidden=!t.videoUrl;if(t.videoUrl)v.href=t.videoUrl;else v.removeAttribute('href');by('tutorial-dialog').showModal();}
let slideIndex=0,photoFocus,revealObserver;
const reducedMotion=matchMedia('(prefers-reduced-motion: reduce)');
function applyMotion(){
 if(revealObserver)revealObserver.disconnect();
 document.querySelectorAll('.reveal-pending,.is-visible').forEach(n=>n.classList.remove('reveal-pending','is-visible'));
 const active=!!config.animations&&!reducedMotion.matches;document.body.classList.toggle('site-motion',active);
 if(!active||typeof IntersectionObserver!=='function')return;
 revealObserver=new IntersectionObserver(entries=>{for(const e of entries)if(e.isIntersecting){e.target.classList.add('is-visible');revealObserver.unobserve(e.target);}},{threshold:.06});
 for(const n of document.querySelectorAll('.hero-copy,.hero-gallery,.hero-visual,.feature-card,.plan-card,.tutorial-card,.app-section,.faq-layout,.contact-section')){n.classList.add('reveal-pending');revealObserver.observe(n);}
}
function renderGallery(){
 const root=by('hero-gallery'),slides=config.heroSlides;root.replaceChildren();root.onkeydown=null;root.hidden=!slides.length;by('hero-demo').hidden=!!slides.length;
 if(!slides.length)return;slideIndex=Math.min(slideIndex,slides.length-1);
 const p=slides[slideIndex],view=make('button','hero-photo-button');view.type='button';view.setAttribute('aria-label','بزرگ‌نمایی '+(p.title||'عکس معرفی'));
 const img=make('img','hero-photo');img.src=p.image;img.alt=p.title||'تصویر معرفی سامانه';img.decoding='async';view.append(img);
 view.addEventListener('click',()=>{photoFocus=view;by('photo-dialog-image').src=p.image;by('photo-dialog-image').alt=img.alt;by('photo-dialog-caption').textContent=p.caption||p.title;by('photo-dialog').showModal();});
 root.append(view);const caption=make('div','hero-photo-caption');if(p.title)caption.append(make('strong','',p.title));if(p.caption)caption.append(make('p','',p.caption));root.append(caption);
 if(slides.length<2)return;
 const controls=make('div','gallery-controls'),previous=make('button','','→'),next=make('button','','←'),dots=make('div','gallery-dots');
 previous.type=next.type='button';previous.setAttribute('aria-label','عکس قبلی');next.setAttribute('aria-label','عکس بعدی');
 const change=(i,focus)=>{slideIndex=(i+slides.length)%slides.length;renderGallery();if(focus)root.querySelector(focus)?.focus({preventScroll:true});};
 previous.addEventListener('click',()=>change(slideIndex-1,'.gallery-controls>button:first-child'));next.addEventListener('click',()=>change(slideIndex+1,'.gallery-controls>button:last-child'));
 slides.forEach((p,i)=>{const dot=make('button');dot.type='button';dot.setAttribute('aria-label','نمایش عکس '+new Intl.NumberFormat('fa-IR').format(i+1));dot.setAttribute('aria-pressed',String(i===slideIndex));dot.addEventListener('click',()=>change(i,'.gallery-dots button:nth-child('+(i+1)+')'));dots.append(dot);});
 controls.append(previous,dots,make('span','gallery-count',new Intl.NumberFormat('fa-IR').format(slideIndex+1)+' / '+new Intl.NumberFormat('fa-IR').format(slides.length)),next);root.append(controls);
 root.onkeydown=e=>{if(['ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();change(slideIndex+(e.key==='ArrowLeft'?1:-1),'.gallery-dots button[aria-pressed=true]');}};
}
function renderDownloads(){
 const links=config.appDownloads;by('download').hidden=!links.length;document.querySelectorAll('[data-app-link]').forEach(n=>n.hidden=!links.length);
 by('app-downloads').replaceChildren(...links.map(d=>{const a=make('a','app-download');a.href=d.url;a.target='_blank';a.rel='noopener noreferrer';const icon=make('span','app-download-icon','↓');icon.setAttribute('aria-hidden','true');const text=make('span');text.append(make('strong','',d.label));if(d.description)text.append(make('small','',d.description));a.append(icon,text,make('span','app-download-arrow','↗'));return a;}));
}
function render(c){
 contentUpdatedAt=Number(c.contentUpdatedAt)||0;config=W.publicContent(c);
 for(const [name,value]of Object.entries(config.theme))document.documentElement.style.setProperty('--'+name,value);
 document.title=config.seoTitle;document.querySelector('meta[name=description]').content=config.seoDescription;
 document.querySelector('meta[name=theme-color]').content=config.theme.primary;
 for(const n of document.querySelectorAll('[data-site]'))n.textContent=config[n.dataset.site]||'';
 for(const n of document.querySelectorAll('[data-site-logo]'))n.src=config.logo||'/favicon.svg';
 by('site-announcement').textContent=config.announcement;by('site-announcement').hidden=!config.announcement;
 by('feature-grid').replaceChildren(...config.features.map(f=>{const a=make('article','feature-card'),icon=make('div','feature-icon');icon.setAttribute('aria-hidden','true');icon.innerHTML='<svg viewBox="0 0 24 24">'+icons[f.icon]+'</svg>';a.append(icon,make('h3','',f.title),make('p','',f.text));return a;}));
 by('plans-grid').replaceChildren(...config.plans.map((p,i)=>{
  const a=make('article','plan-card'+(p.badge?' featured':''));if(p.badge)a.append(make('span','plan-badge',p.badge));
  const top=make('div','plan-top');top.append(make('h3','',p.name),make('span','plan-index',String(i+1).padStart(2,'0')));a.append(top,make('p','plan-description',p.description));
  const price=make('div','plan-price',p.price===null?'استعلام قیمت':p.price===0?'رایگان':new Intl.NumberFormat('fa-IR').format(p.price));if(p.price!==null&&p.price>0)price.append(make('small','','تومان'));
  const btn=make('button','button '+(p.badge?'button-teal':'button-outline'),'انتخاب بسته و هماهنگی ←');btn.type='button';btn.dataset.plan=p.id;btn.addEventListener('click',()=>choosePlan(p.id));
  const list=make('ul','plan-features');for(const m of p.modules){const meta=W.modules.find(x=>x.id===m);if(meta)list.append(make('li','',meta.label));}for(const e of p.extras)list.append(make('li','',e));
  a.append(price,make('p','plan-period',p.period+' · دورهٔ '+new Intl.NumberFormat('fa-IR').format(p.months)+'ماهه'),btn,make('p','plan-capacity','تا '+new Intl.NumberFormat('fa-IR').format(p.maxUsers)+' دانش‌آموز · '+(p.shifts===2?'دو شیفت':'یک شیفت')),list);return a;
 }));
 if(!config.plans.length)by('plans-grid').append(make('p','','برای انتخاب بستهٔ متناسب با مدرسه با ما تماس بگیرید.'));
 const selected=by('request-plan').value;by('request-plan').replaceChildren(...config.plans.map(p=>{const o=make('option','',p.name);o.value=p.id;return o;}));if(config.plans.some(p=>p.id===selected))by('request-plan').value=selected;by('request-submit').disabled=!config.plans.length;
 by('tutorial-grid').replaceChildren(...config.tutorials.map((t,i)=>{const a=make('article','tutorial-card'),art=make('div','tutorial-art');art.setAttribute('aria-hidden','true');art.append(make('span','','راهنمای '+new Intl.NumberFormat('fa-IR').format(i+1)),make('div','play','▷'));const body=make('div','tutorial-body'),btn=make('button','','باز کردن راهنما ←');btn.type='button';btn.addEventListener('click',()=>openTutorial(t));body.append(make('small','',t.audience),make('h3','',t.title),make('p','',t.summary),btn);a.append(art,body);return a;}));
 by('faq-list').replaceChildren(...config.faqs.map(f=>{const d=make('details');d.append(make('summary','',f.question),make('p','',f.answer));return d;}));
 by('contact-links').replaceChildren(...config.contacts.map(c=>{const a=make('a','contact-link');a.href=c.url;if(c.url.startsWith('https:')){a.target='_blank';a.rel='noopener noreferrer';}a.append(make('b','',c.label),make('span','',c.display||c.url));return a;}));
 renderGallery();renderDownloads();applyMotion();
}
const motionChanged=()=>{if(config)applyMotion();};if(reducedMotion.addEventListener)reducedMotion.addEventListener('change',motionChanged);else reducedMotion.addListener(motionChanged);
by('photo-dialog').querySelector('.close-dialog').addEventListener('click',()=>by('photo-dialog').close());
by('photo-dialog').addEventListener('close',()=>{by('photo-dialog-image').removeAttribute('src');if(photoFocus&&photoFocus.isConnected)photoFocus.focus();});
by('menu-toggle').addEventListener('click',()=>{const b=by('menu-toggle'),open=b.getAttribute('aria-expanded')!=='true';b.setAttribute('aria-expanded',String(open));by('main-nav').classList.toggle('open',open);});
for(const a of by('main-nav').querySelectorAll('a'))a.addEventListener('click',()=>{by('menu-toggle').setAttribute('aria-expanded','false');by('main-nav').classList.remove('open');});
by('tutorial-dialog').querySelector('.close-dialog').addEventListener('click',()=>by('tutorial-dialog').close());by('tutorial-dialog').addEventListener('close',()=>{if(previousFocus)previousFocus.focus();});by('tutorial-dialog').addEventListener('click',e=>{if(e.target===by('tutorial-dialog')){const r=e.target.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)e.target.close();}});
by('request-form').addEventListener('submit',async e=>{
 e.preventDefault();const f=e.currentTarget,button=by('request-submit'),status=by('request-status');if(button.disabled)return;
 const body=Object.fromEntries(new FormData(f));delete body.consent;
 const signature=JSON.stringify(body);if(!requestKey||signature!==requestSignature){requestKey=key();requestSignature=signature;}body.requestKey=requestKey;body.contentUpdatedAt=contentUpdatedAt;
 button.disabled=true;status.className='';status.textContent='در حال ثبت درخواست…';
 const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),20000);
 try{
  const response=await fetch('/api/website/requests',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),signal:ctrl.signal});const data=await response.json();
  if(!response.ok||!data.ok){if(['price_changed','plan_unavailable'].includes(data.error)){const fresh=await fetch('/api/website',{cache:'no-store'});if(fresh.ok){const next=await fresh.json();render({...next.content,contentUpdatedAt:next.updatedAt});}}const messages={invalid_request:'نام مدرسه، نام مسئول و موبایل ۱۱رقمی معتبر را بررسی کنید.',plan_unavailable:'این بسته دیگر در دسترس نیست. بسته‌های تازه دریافت شدند؛ انتخاب خود را بررسی و دوباره ارسال کنید.',price_changed:'قیمت یا مشخصات بسته به‌روز شد. پیش از ارسال دوباره، بسته و قیمت تازه را بررسی کنید. اطلاعات فرم حفظ شده است.',too_many_requests:'چند درخواست در زمان کوتاه ثبت شده است؛ کمی بعد دوباره تلاش کنید.',request_key_conflict:'درخواست قبلی تغییر کرده است؛ دوباره تلاش کنید.'};throw Error(messages[data.error]||'ثبت درخواست انجام نشد؛ دوباره تلاش کنید.');}
  status.className='success';status.textContent='درخواست شما ثبت شد. برای هماهنگی با شما تماس می‌گیریم.\nکد پیگیری: '+data.receipt+'\nثبت درخواست به معنی پرداخت یا فعال‌سازی بسته نیست.';
  for(const el of f.elements)el.disabled=true;
  const again=make('button','button button-outline','ثبت درخواست تازه');again.type='button';again.addEventListener('click',()=>{for(const el of f.elements)el.disabled=false;f.reset();requestKey='';requestSignature='';status.textContent='';again.remove();});status.after(again);
 }catch(error){status.className='error';status.textContent=error.name==='AbortError'?'پاسخ سرور دیر رسید. اطلاعات فرم حفظ شده؛ با تلاش دوباره درخواست تکراری ساخته نمی‌شود.':error instanceof TypeError?'ارتباط برقرار نشد؛ اطلاعات فرم حفظ شده است. دوباره تلاش کنید.':error.message;button.disabled=!config.plans.length;}finally{clearTimeout(timer);}
});
try{render(JSON.parse(by('website-data').textContent));}catch(error){render(W.defaults);fetch('/api/website',{cache:'no-store'}).then(r=>{if(!r.ok)throw Error();return r.json();}).then(d=>render({...d.content,contentUpdatedAt:d.updatedAt})).catch(()=>{});}
})();
